
import { defuFn } from '/Users/hugovega/Documents/nuxt3/tweeterdemo/node_modules/defu/dist/defu.mjs'

const inlineConfig = {}



export default defuFn(inlineConfig)
