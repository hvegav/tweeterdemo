import { NuxtModule } from '@nuxt/schema'
declare module '@nuxt/schema' {
  interface NuxtConfig {
    ["tailwindcss"]?: typeof import("@nuxtjs/tailwindcss").default extends NuxtModule<infer O> ? Partial<O> : Record<string, any>
    ["security"]?: typeof import("nuxt-security").default extends NuxtModule<infer O> ? Partial<O> : Record<string, any>
    ["telemetry"]?: typeof import("@nuxt/telemetry").default extends NuxtModule<infer O> ? Partial<O> : Record<string, any>
  }
  interface RuntimeConfig {
     app: {
        baseURL: string,

        buildAssetsDir: string,

        cdnURL: string,
    },

    security: {
        headers: {
             crossOriginResourcePolicy: {
                   value: string,

                   route: string,
             },

             crossOriginOpenerPolicy: {
                   value: string,

                   route: string,
             },

             crossOriginEmbedderPolicy: {
                   value: string,

                   route: string,
             },

             contentSecurityPolicy: {
                   value: string,

                   route: string,
             },

             originAgentCluster: {
                   value: string,

                   route: string,
             },

             referrerPolicy: {
                   value: string,

                   route: string,
             },

             strictTransportSecurity: {
                   value: string,

                   route: string,
             },

             xContentTypeOptions: {
                   value: string,

                   route: string,
             },

             xDNSPrefetchControl: {
                   value: string,

                   route: string,
             },

             xDownloadOptions: {
                   value: string,

                   route: string,
             },

             xFrameOptions: {
                   value: string,

                   route: string,
             },

             xPermittedCrossDomainPolicies: {
                   value: string,

                   route: string,
             },

             xXSSProtection: {
                   value: number,

                   route: string,
             },
        },

        requestSizeLimiter: {
             value: {
                   maxRequestSizeInBytes: number,

                   maxUploadFileRequestInBytes: number,
             },

             route: string,
        },

        rateLimiter: {
             value: {
                   tokensPerInterval: number,

                   interval: string,

                   fireImmediately: boolean,
             },

             route: string,
        },

        xssValidator: {
             value: any,

             route: string,
        },

        corsHandler: {
             value: {
                   origin: string,

                   methods: Array<string>,

                   preflight: {
                          statusCode: number,
                   },
             },

             route: string,
        },

        allowedMethodsRestricter: {
             value: string,

             route: string,
        },

        hidePoweredBy: boolean,

        basicAuth: boolean,
    },
  }
  interface PublicRuntimeConfig {
  
  }
}