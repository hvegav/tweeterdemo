<template>
  <div>
   <h1 class="text-red-500">Hola Mundo</h1>
  </div>
</template>
