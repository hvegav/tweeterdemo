// nitro.config.ts
import { defineNitroConfig } from 'nitropack'
export default defineNitroConfig({
    preset: 'aws-lambda'
})